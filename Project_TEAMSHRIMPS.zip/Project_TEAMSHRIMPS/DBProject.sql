DROP TABLE accounts CASCADE CONSTRAINTS;

DROP TABLE clients CASCADE CONSTRAINTS;

DROP TABLE locations CASCADE CONSTRAINTS;

DROP TABLE transactions CASCADE CONSTRAINTS;

CREATE TABLE clients(
    client_id INT NOT NULL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    phone_number VARCHAR(50),
    home_branch VARCHAR(50),
    account_type VARCHAR(50),
    balance VARCHAR(50)
);

CREATE TABLE accounts(
    account_id int NOT NULL PRIMARY KEY,
    account_type VARCHAR(50),
    account_status VARCHAR(50),
    client_id int,
    balance VARCHAR(50),
    CONSTRAINT fk_client_id FOREIGN KEY (client_id) REFERENCES clients(client_id)
);

CREATE TABLE locations(
    location_id int NOT NULL PRIMARY KEY,
    client_id int,
    address VARCHAR(50),
    city VARCHAR(50),
    province VARCHAR(50),
    country VARCHAR(50),
    CONSTRAINT fk_location_client_id FOREIGN KEY (client_id) REFERENCES clients(client_id)
);

CREATE TABLE transactions(
    transaction_id INT NOT NULL PRIMARY KEY,
    customer_id INT,
    transaction_type VARCHAR(50),
    amount VARCHAR(50),
    "date" VARCHAR(50),
    CONSTRAINT fk_customer_id FOREIGN KEY (customer_id) REFERENCES clients(client_id)
);

select * from Clients;
select * from Accounts;
select * from Locations;
select * from Transactions;
\create table audit_log(
    user_name varchar(20) not null,
    operation_performed varchar(20) not null,
    date_of_operation date not null,
    id_changed int not null
    
    );

create or replace trigger audit_changes
before delete or insert or update
on accounts
begin 
    if inserting then 
    insert into audit_log
    values(user, 'INSERT', SYSDATE, :new.account_id);
    end if;
    if updating then
    insert into audit_log
    values(user, 'UPDATE', SYSDATE, :old.account_id);
    end if;
    if deleting then
    insert into audit_log
    values(user, 'DELETE', SYSDATE, :old.account_id);
    end if;
end;